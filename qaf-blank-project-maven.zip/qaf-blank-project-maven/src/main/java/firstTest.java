import org.testng.annotations.Test;
import com.qmetry.qaf.automation.step.WsStep;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class firstTest {
	
	@Test()
	public void test(){
		WsStep.userRequests("groupkt.call");
		WsStep.responseShouldHaveStatusCode(200);
	
		
	}

}
